import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
public class sample extends Frame implements ActionListener {

    String msg;
    int i = 400, j = 300;
    String x;
    boolean clear;
    String name = null;

   Button b2 = new Button("reset");
   Button b1=new Button("save");
   Label l11=new Label("Student details",Label.CENTER);
   Label l1=new Label("GRE SCORE",Label.LEFT);
   Label l2=new Label("AGE",Label.LEFT);
   Label l3=new Label("GENDER",Label.LEFT);
   Label l4=new Label("STATE",Label.LEFT);
   Label l5=new Label("COURSE",Label.LEFT);
   TextField t1=new TextField();
   Choice c1=new Choice();
   CheckboxGroup cbg=new CheckboxGroup();
   Checkbox ck1=new Checkbox("Male",false,cbg);
   Checkbox ck2=new Checkbox("Female",false,cbg);
   TextArea t2=new TextArea("",180,90,TextArea.SCROLLBARS_VERTICAL_ONLY);
   Choice course=new Choice();
   Choice age=new Choice();

   public sample(){
	addWindowListener(new myWindowAdapter());
	setBackground(Color.LIGHT_GRAY);
 	setForeground(Color.black);
	setLayout(null);
 	add(l11);
 	add(l1);
 	add(l2);
 	add(l3);
 	add(l4);
 	add(l5);
        add(t1);
        add(t2);
        add(ck1);
        add(ck2);
        add(course);
        add(age);
        add(b1);
        add(b2);
        b1.addActionListener(this);
        b2.addActionListener(this);
        course.add("MS CSE");
        course.add("BSc maths");
        course.add("BSc physics");
        course.add("BA English");
        course.add("BCOM");
        age.add("17");
        age.add("18");
        age.add("19");
        age.add("20");
        age.add("21");
        l1.setBounds(25,65,90,20);
        l2.setBounds(25,90,90,20);
        l3.setBounds(25,120,90,20);
        l4.setBounds(25,185,90,20);
        l5.setBounds(25,260,90,20);
        l11.setBounds(10,40,280,20);
        t1.setBounds(120,65,170,20);
        t2.setBounds(120,185,170,60);
        ck1.setBounds(120,120,50,20);
        ck2.setBounds(170,120,60,20);
        course.setBounds(120,260,100,20);
        age.setBounds(120,90,50,20);
        b1.setBounds(120,350,50,30);
        b2.setBounds(180,350,50, 30);
    }

    public void actionPerformed(ActionEvent ae) {

        Graphics page = this.getGraphics();
        x = t1.getText();

        if(ae.getActionCommand().equals("save")) {
            try {
	        Class.forName("com.mysql.jdbc.Driver");
	        Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/sample","root","root");  
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select uniname from uni where grescore > " + x);
                while(rs.next()){
                    name = rs.getString(1);
                    page.drawString(name, i, j);
                    j = j + 10;
                }
                con.close();
            } catch(Exception e) {
	          System.out.println("Exception Occurred");
            } 
       }

       if(ae.getActionCommand().equals("reset")) {
	   page.setColor(getBackground());
	   page.fillRect(0,0,(int)this.getWidth(),(int)this.getHeight());
	   clear=true;
       }
    }

    public static void main(String g[]) {

        sample stu=new sample();
        stu.setSize(new Dimension(500,500));
        stu.setTitle("student registration");
        stu.setVisible(true);
    }
}

class myWindowAdapter extends WindowAdapter {
    public void windowClosing(WindowEvent we) {
        System.exit(0);
    }
}